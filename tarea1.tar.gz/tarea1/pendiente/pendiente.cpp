//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

void plano(void)
{
	glColor3f(1.0,0.4,0.8);
    glBegin(GL_LINES);
    glVertex2f(20.0f,0.0f);
    glVertex2f(-20.0f,0.0f);
    glVertex2f(0.0f,20.0f);
    glVertex2f(0.0f,-20.0f);
    glEnd();
}

void pendiente()
{
	glBegin(GL_POINTS);
    glPointSize(30.0f);
	double y=0;
	for(double i=-4; i<=4; i++)//dibujando los puntos encontrados
	{
		y=(3*i)+7;
        glColor3f(1.0f, 0.0f, 0.0f);//red
        glVertex2f(i,y);
	}
    for(double i=-4; i<=4;i+=0.2)//dibujando los puntos que complementan el trazo
    {
		y=(3*i)+7;
		glColor3f(0.0f, 0.0f, 1.0f);//Blue
		glVertex2f(i,y);
	}	
}
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    plano();
    pendiente();  
    glEnd();
    glFlush ();
}


void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-20.0, 20.0, -20.0, 20.0, -20.0, 20.0); 
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (500, 500);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("pendiente");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

