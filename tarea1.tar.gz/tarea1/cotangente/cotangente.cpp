//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

void plano(void)
{
	glColor3f(1.0,0.4,0.8);
    glBegin(GL_LINES);
    glVertex2f(20.0f,0.0f);
    glVertex2f(-20.0f,0.0f);
    glVertex2f(0.0f,20.0f);
    glVertex2f(0.0f,-20.0f);
    glEnd();
}

void cotangente()
{
	glBegin(GL_POINTS);
    glPointSize(5.0f);
    double y=0;
    double pi3=-3*M_PI;
    double pim3=3*M_PI;
    for(double i=pi3; i<=pim3;i+=0.01)
    {
	   y=1/tan(i);//ecuacion cotangente
	   glColor3f(0.0f, 0.0f, 1.0f);//Blue
	   glVertex2f(i,y);
	 }
}
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    plano();
    cotangente();
    glEnd();
    glFlush ();
}


void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-5.0, 5.0, -5.0, 5.0, -5.0, 5.0); 
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (500, 500);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("cotangente");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

