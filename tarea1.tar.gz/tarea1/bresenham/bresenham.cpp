//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

void bresenham(void)
{
	double xinicial=-4;
	double yinicial=-4;
	double xfinal=4;
	double yfinal=4;
	double x=0;
	double y=0;
	double deltax,deltay,constantep,ultimo;
	deltax=abs(xfinal-xinicial);
	deltay=abs(yfinal-yinicial);
	constantep=2*deltay-deltax;
	
	if(xinicial>xfinal)
	{
		x=xfinal;
		y=yfinal;
		ultimo=xinicial;
	}else
		{
			x=xinicial;
			y=yinicial;
			ultimo=xfinal;
		}
			 
		glBegin(GL_POINTS);
        glColor3f(1.0, 1.0, 0.5);
		glVertex2f(x, y);
		glEnd();
		float x1=x;
		float y1=y;   
        while(x<ultimo)
        {
			 x+=.1;
			 if(constantep<0)
			 {
				 constantep+=2*deltay;
			 }else
				{
					 y+=.1;
					 constantep+=2*(deltay-deltax);
				}
				glVertex2f(x, y);
		}
	glBegin(GL_LINES);
	glVertex2f(x, y);
	glVertex2f(x1, y1);
}
void plano(void)
{
	glColor3f(1.0,0.4,0.8);
    glBegin(GL_LINES);
    glVertex2f(4.0f,0.0f);
    glVertex2f(-4.0f,0.0f);
    glVertex2f(0.0f,4.0f);
    glVertex2f(0.0f,-4.0f);
	}
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    plano();
    glEnd();
    bresenham();
	glEnd();
    glFlush();
}


void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-4.0, 4.0, -4.0, 4.0, -4.0, 4.0); 
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (500, 500);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("Algoritmo de bresenham");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

