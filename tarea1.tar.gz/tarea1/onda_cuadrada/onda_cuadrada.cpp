//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

void plano(void)
{
	glColor3f(1.0,0.4,0.8);
    glBegin(GL_LINES);
    glVertex2f(10.0f,0.0f);
    glVertex2f(-10.0f,0.0f);
    glVertex2f(0.0f,10.0f);
    glVertex2f(0.0f,-10.0f);
    glEnd();
}
void onda_cuadrada(void)
{
	 
   glBegin(GL_LINES);
   float y=0;
   float pi3=-3*M_PI;
   float pim3=5*M_PI;
   float k=2;//constante k
   for(float i=pi3; i<=pim3;  i+=(M_PI))
   {
	   y=k+((4*k)/M_PI)*(sin(i)+(1/3)*sin(3*i)+(1/5)*sin(5*i));
	   glColor3f(0.0f, 0.0f, 1.0f);//Blue
	   glVertex2f(i,y);
	   glVertex2f(i,0);
	   glVertex2f(i,y);
	}
}
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    plano(); 
    onda_cuadrada();
    glEnd();
    glFlush ();	
}


void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-10.0, 10.0, -10.0, 10.0, -10.0, 10.0); 
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (500, 500);
    glutInitWindowPosition (100, 100);
    glutCreateWindow ("onda cuadrada");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

