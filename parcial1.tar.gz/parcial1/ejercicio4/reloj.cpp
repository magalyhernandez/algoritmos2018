//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
float ortho=10;
float hora = 0;
float segundo=0;
float minutos = 0;
void plano(){
	glBegin(GL_LINES);
		glVertex2f(0,10);
	glVertex2f(0,-10);
		glVertex2f(10,0);
	glVertex2f(-10,0);
	glEnd();

	}

GLint ancho=800;
GLint alto=600; 

void lineas(GLdouble x1,GLdouble y1,GLdouble x2,GLdouble y2,float t)
{
	glBegin(GL_LINES);
	  glLineWidth(t);
	glVertex2f(x1,y1);
	glVertex2f(x2,y2);
	glEnd();

}
void circulos(float x, float y, float anguloI, float anguloF,float r)
{
   glBegin(GL_POINTS);
  GLfloat cx=x;
  GLfloat cy=y;
  GLfloat angulo;
  for (GLfloat i=anguloI; i<anguloF; i+=1){
    angulo= i*M_PI/180.0f;
    cx=r*cos(angulo)+x;
    cy=r*sin(angulo)+y;
    glVertex2f(cx,cy);
  }
   glEnd();
}
void cuadros(float x, float y, float h, float w, float inclinacion){
  glBegin(GL_QUADS);
  glVertex2f(x,y);
  glVertex2f(x-inclinacion, y+h);
  glVertex2f(x+w-inclinacion, y+h+inclinacion);
  glVertex2f(x+w, y+inclinacion);
  glEnd();
}
void agujas(float x, float y, float d, float angulo, float t){
  glLineWidth(t);
  float cx=0;//punto en x
  float cy=0;//punto en y
  float a;
  for (GLfloat i=360; i>=angulo; i-=0.1){
    
        a= i*M_PI/180.0f;
        cx=d*cos(i*M_PI/180.0f)+x;
        cy=d*sin(i*M_PI/180.0f)+y;
  }
  lineas(x,y,cx, cy,t);

}

void display(void)
{
	glClearColor(1,1,1,0.0); 
    glClear(GL_COLOR_BUFFER_BIT);
  
    glColor3f(0.0f,0.0f,0.0f); 
     glPointSize(10);
  circulos(0,0,0,360,5);
    cuadros(4,-0.2,0.5,0.5,0);
   cuadros(3.5,2,0.001,0.5,0.3);
   cuadros(2,3.5,0.000001,0.5,0.5);
   
  cuadros(-0.2,4,0.5,0.5,0);
   
    cuadros(-4,2.5,0.001,0.5,-0.3);
   cuadros(-2.5,4,0.000001,0.5,-0.5);
   
    cuadros(-4,-0.2,0.5,0.5,0);
    
      cuadros(-3.5,-2,0.001,0.5,0.3);
   cuadros(-2,-3.5,0.000001,0.5,0.5);
   
   cuadros(-0.2,-4,0.5,0.5,0);
   
   cuadros(3,-1.5,0.001,0.5,-0.3);
   cuadros(2,-3,0.000001,0.5,-0.5); 
   
    agujas(0,0, 3, hora, 10.0f);
    agujas(0,0, 3.5, minutos, 8.0f);
    agujas(0,0, 3.7, segundo, 8.0f);
    

   
    glEnd();
    glFlush ();
}

 
// Función para controlar teclas normales del teclado.
void keyboard(unsigned char key, int x, int y)
{
    //control de teclas que hacen referencia a Escalar y transladar el cubo en los ejes X,Y,Z.
    switch (key)
    {
    case '1':
    
         hora -= 1;
        break;
    case '2':
		minutos-=1;
		break;
	case '3':
		segundo-=1;
		break;
		case '4':
		hora=0;
		minutos=0;
		segundo=0;
		hora-=55;
		minutos-=270;
		segundo-=270;
		break;
    case 27:		// exit
		exit(0);
    }
    glutPostRedisplay();
}



void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(ortho), ortho, -(ortho), ortho, -(ortho), ortho); 
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 600);
    glutInitWindowPosition (50, 300);
    glutCreateWindow ("Reloj");
    init ();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}

