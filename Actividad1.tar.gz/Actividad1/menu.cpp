#include <GL/gl.h>
#include <GL/glut.h>
#include <stdlib.h>

int id_menu[8]; 

GLfloat X = 0.0f;
GLfloat Y = 0.0f;
GLfloat Z = 0.0f;
float rx;
float ry;
GLint ancho;
GLint alto;
void reshape(int w, int h)
{
    glViewport(0, 0, w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-1,4,-4, 1, -4, 4);
    glMatrixMode(GL_MODELVIEW);
    ancho = w;
    alto = h;
}
void init(void)
{

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0); //Activamos las luces en 0
    glDepthFunc(GL_LESS); //comparación de profundidad
    glEnable(GL_DEPTH_TEST); //activa GL_DEPTH_TES
  	// Queremos que se dibujen las caras frontales
  	// y con un color solido de relleno.
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}
void motion(int x, int y){
        rx=x;
		ry=y*-1;
	glutPostRedisplay();
     //cuando se ha movido el ratón y la magnitud de su desplazamiento
}
void mousebutton(int button, int state, int x, int y){
	if((button==GLUT_RIGHT_BUTTON)&(state==GLUT_DOWN))
		{
			rx=x;
			ry=y*-1;
		}
} 
void traslacion(){

    //Translación
    glTranslatef(rx/150,ry/150, 0.0); 
	}

void material(float ax,float ay,float az,float dx,float dy,float dz,float sx,float sy,float sz,float sh){
	 glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	 glLoadIdentity();
    
// Propiedades del material
    GLfloat mat_ambient[] = { ax, ay, az};
    GLfloat mat_diffuse[] = {dx,dy,dz};
    GLfloat mat_specular[] = {sx,sy,sz};
    GLfloat shine[] = {sh};
// "Limpiamos" el frame buffer con el color de "Clear", en este
// caso negro.
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode( GL_MODELVIEW_MATRIX );

// Dibujamos una "Tetera" y le aplico el material
    glPushMatrix();
//setMaterial
    glMaterialfv(GL_FRONT,GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT,GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT,GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT,GL_SHININESS, shine);
    traslacion();
    glEnd();
    glFlush();

}

void dona()
{
	glClear (GL_COLOR_BUFFER_BIT);
      glutSolidTorus(0.5, 1.0, 20, 20);
     
   glEnd();
    glFlush ();
	}
void tetera()
{
	glClear(GL_COLOR_BUFFER_BIT);
    glRotatef(15, 1.0, 0.0, 0.0);
	
      glutSolidTeapot(1.0);	
        glEnd();
    glFlush();
	}
void cono()
{
	glClear(GL_COLOR_BUFFER_BIT);
    glRotatef(40, 0.0, 1.0, 0.0); 
	  
      glutSolidCone(1,1,10,10);
      glEnd();
    glFlush();
	}
void octaedro(){
	glClear(GL_COLOR_BUFFER_BIT);
	glRotatef(-80, 1.0, 0.0, 0.0); 
	
       glutSolidOctahedron();
       glFlush();
    glutSwapBuffers();
	}
void dodecaedro(){
	
	glRotatef(-80, 1.0, 0.0, 0.0); 
	   glutSolidDodecahedron();
	    glEnd();
    glFlush();
	}
void icosaedro(){
	glRotatef(15, 1.0, 0.0, 0.0); 
	glClear(GL_COLOR_BUFFER_BIT);		
       glutSolidIcosahedron();
        glEnd();
    glFlush();
	}
void cubo(){
	glClear(GL_COLOR_BUFFER_BIT);
	glRotatef(65, 1.0, 1.0, 0.0); 
       glutSolidCube(1.0f);
      glEnd();
    glFlush();
	}

void menu(int valor){
 id_menu[1]=valor; 
  switch (valor) {
    case 1:
		 material(0.0, 0.0, 0.0, 0.5, 0.5, 0.0, 0.60, 0.60, 0.50, 0.25);
		 dona();
      break;
    case 2:
		  material(1.0, 1.0, 1.0, 1.5, 1.5, 1.0, 1.60, 1.60, 1.50, 1.25);
		  tetera();
      break;
    case 3:
		 material(0.0215, 0.1745, 0.0215, 0.07568, 0.61424, 0.07568, 0.633, 0.727811, 0.633, 0.6);
		cono();
      break;
     case 4:
		material(0.0, 0.0, 0.0, 0.5, 0.5, 0.0, 0.60, 0.60, 0.50, 0.25);
		octaedro();
       break;
     case 5:
		material(0.1, 0.18725, 0.1745, 0.396, 0.74151, 0.69102, 0.297254, 0.30829, 0.306678, 0.1);
		dodecaedro();
       break;
     case 6:
		material(0.0, 0.05, 0.0, 0.4, 0.5, 0.4, 0.04, 0.7, 0.04, 0.078125);
		icosaedro();
       break;
     case 7:
		 material(0.05, 0.0, 0.0, 0.5, 0.4, 0.4, 0.7, 0.04, 0.04, 0.078125);
		cubo();
       break;
       case 8:
       exit(0);
  }
 glutPostRedisplay();
glFlush();

}
void redraw( void ){
    glClear(GL_COLOR_BUFFER_BIT);
    menu(id_menu[1]);
    glColor3f(1.0,1.0,0.0);
	glutSwapBuffers();
}

int main(int argc, char **argv)
{    ancho = 600;
    alto = 600;
	 //  Inicializar los parámetros GLUT y de usuario proceso
    glutInit(&argc, argv);
    // Solicitar ventana con color real y doble buffer con Z-buffer
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glutInitWindowSize(ancho, alto);
    glutInitWindowPosition (200,100);
    // Crear ventana
    glutCreateWindow("Menu figuras");
    glClearColor(0.0, 0.0, 0.0, 0.0);//Agrandole color a la ventana
     init();
    // Habilitar la prueba de profundidad de Z-buffer
    glEnable(GL_DEPTH_TEST);
    // Creación del menú que permite ver las figuras ingresadas
      glutCreateMenu(menu);
      glutAddMenuEntry("Dona",1);
      glutAddMenuEntry("Tetera",2);
      glutAddMenuEntry("Cono",3);
      glutAddMenuEntry("Octaedro",4);
      glutAddMenuEntry("Dodecaedro",5);
      glutAddMenuEntry("Icosaedro",6);
      glutAddMenuEntry("Cubo",7);
      glutAddMenuEntry("Salir",8);
      glutAttachMenu(GLUT_RIGHT_BUTTON); // Eligiendo con el click derecho del raton
	  glMatrixMode(GL_PROJECTION);
      glLoadIdentity();
	  glutIdleFunc(redraw);
      glutReshapeFunc(reshape);
      glutMotionFunc(motion);//(arrastre activo) se ejecuta cuando hay eventos del ratón, tales como tener pulsado el botón izquierdo o derecho
      glutMouseFunc(mousebutton);//permiten registrar los eventos producidos por los clicks del ratón
     // Funciones de retrollamada
	  glutDisplayFunc(redraw);
    // Pasar el control de eventos a GLUT
      glutMainLoop();
    // Regresar al sistema operativo
      return 0;
}
