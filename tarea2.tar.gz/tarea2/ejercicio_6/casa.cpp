//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
float ortho=25;

void lineas(GLdouble x1,GLdouble y1,GLdouble x2,GLdouble y2)
{
	glBegin(GL_LINES);
	glVertex2f(x1,y1);
	glVertex2f(x2,y2);
	glEnd();

}
void ventanas(float x, float y, float h, float w, float angulo, float numero){
  //marco 1.0
  lineas(x,y,x,y+h);

  float cx=0;
  float cy=0;
  float a;
  for (GLfloat i=0; i<=angulo; i+=0.01){
        a= i*M_PI/180.0f;
        cx=w*cos(a)+x;
        cy=w*sin(a)+y;
  }
  lineas(x,y,cx, cy);
  lineas(x,y+h,cx, cy+h);
  lineas(cx, cy+h,cx, cy);
//marco 1.1
if(angulo<=90){
x+=0.2;
y+=0.3;
w-=0.5;
h-=0.5;}
if(angulo>90 && angulo<=180){
  x-=0.2;
  y+=0.3;
  w-=0.5;
  h-=0.5;
}
lineas(x,y,x,y+h);

for (GLfloat i=0; i<=angulo; i+=0.01){
      a= i*M_PI/180.0f;
      cx=w*cos(a)+x;
      cy=w*sin(a)+y;
}
lineas(x,y,cx, cy);
float cx1=cx,cy1=cy;
lineas(x,y+h,cx, cy+h);
lineas(cx, cy+h,cx, cy);
//marco 1.2
  y+=0.3;
  w-=0.2;
  h-=0.3;
lineas(x,y,x,y+h);
for (GLfloat i=0; i<=angulo; i+=0.01){
      a= i*M_PI/180.0f;
      cx=w*cos(a)+x;
      cy=w*sin(a)+y;
}
lineas(x,y,cx, cy);
lineas(cx, cy,cx1,cy1);
lineas(cx, cy+h,cx, cy);
//
//ventanas
float ancho= (w/numero); //ancho del marcho entre numero de ventanas
float nx,ny;
for(float j=1;j<=numero;j++){
  //Lineas(x,y,cx, cy, 0.1,0.0,0.2);
  if(j>1){

  w=ancho;
  y=ny;
  x=nx;
}else{
  y+=0.2;
  w=ancho-0.1;
  h-=0.2;

}
 // Lineas(cx+0.2, cy+h+0.2,cx+0.2, cy+0.2, 0.1,0.0,0.2);
  for (GLfloat i=0; i<=angulo; i+=0.01){
        a= i*M_PI/180.0f;
        cx=w*cos(a)+x;
        cy=w*sin(a)+y;
  }

  lineas(x,y,cx, cy);
  lineas(cx, cy+h,cx, cy);
  if(numero>j){
	  lineas(cx-0.1, cy+h,cx-0.1, cy);
	  lineas(cx+0.1, cy+h,cx+0.1, cy);
	}
  nx=cx;
  ny=cy;
}


}

void casa()
{
	glColor3f(0,0,1);
	//cochera
	lineas(-10,-19,-10,-12);//linea izquierda por porton
	lineas(-10,-19,-19,-13);//linea inferior pared
	lineas(-9.5,-19,-9.5,-12.6);//linea derecha porton d=0.5
	lineas(-19,-13,-19,-7);//linea izquierda de cochera
	lineas(-10,-19,-9.5,-19);
	lineas(-9.5,-12.5,-4,-10);//linea superior porton d=5.5
	lineas(-9.5,-13,-8,-18);//linea izq porton 
	lineas(-8,-18,-2.5,-15);//linea inferior porton
	lineas(-4.4,-10.2,-2.5,-15);//linea derecha porton
	//techo cochera
	lineas(-10.2,-12.2,-6.6,-8.5);//techo frente
	lineas(-6.6,-8,-3.5,-9.2);//
	lineas(-10.3,-11.8,-19.2,-6.7);//linea superior cochera d=0.3
	lineas(-10.45,-12.1,-19.2,-7);//linea superior cochera
	lineas(-19.2,-6.7,-19.2,-7);
	lineas(-10.45,-12.1,-10.2,-12.2);
	lineas(-10.3,-11.8,-6.6,-8);//linea superior techo frente
	lineas(-6.6,-8.5,-3.5,-9.5);//
	lineas(-19.2,-6.7,-16.5,-3);//linea superior izq techo
	lineas(-16.5,-3,-6.6,-8);
	lineas(-3.5,-9.2,-3.5,-12.2);//linea derecha cochera
	lineas(-4,-10,-4,-11);
	lineas(-4.15,-10.1,-4.15,-10.8);
	lineas(-16.5,-3,-3.5,-9.2);//techo medio
	lineas(-3.5,-15.6,-3.5,-16.7);
	lineas(-3.9,-15.8,-3.9,-16.8);
	lineas(-4.05,-15.8,-4.05,-16.7);
	lineas(-3.5,-16.7,-3.9,-16.8);
	lineas(-4.05,-16.7,-3.9,-16.8);
	//casa primera planta
	lineas(-2.5,-17,-2.5,1);//linea par de cochera
	lineas(-15,-1.5,-2.5,-7);// division plantas
	lineas(-15,-3.8,-15,6.5);//linea par de ventana izq
	lineas(-3.5,-16.7,-2.5,-17);
	lineas(-2.5,-7,1,-5);//division puerta segnda planta
	lineas(1,-14.3,1,-8.36); //division cuarto
	lineas(1,-7.2,1,2.5); //division cuarto
	//puerta
	lineas(-1.6,-7.5,0.4,-6.3);//superior techito de puerta
	lineas(0.4,-6.3,1.5,-8);//linea derecha techito puerta
	lineas(-1.6,-7.5,-0.5,-9.2);//linea izquierda techito puerta
	lineas(-0.5,-9.2,1.5,-8);//linea inferior techito pueta
	lineas(-1.7,-7.6,-0.6,-9.2);
	lineas(-1.6,-7.5,-1.6,-9);
	lineas(-1.6,-9,-0.5,-9.2);
	lineas(-1.4,-16,-1.4,-9);//linea izquierda de puerta
	lineas(0.4,-14.7,0.4,-8.7);//linea derecha de puerta
	lineas(-2.5,-17,-1.4,-16);
	lineas(-1.4,-16,-0.3,-16.1);//alfombra
	lineas(-1.4,-15.8,0.4,-14.5);
	lineas(-1.4,-16,0.4,-14.7);//pie puerta
	lineas(-0.3,-16.1,1,-15);
	lineas(1,-15,0.3,-14.8);
	lineas(1,-14.3,0.3,-14.8);
	lineas(-2.5,1,1,2.5);//linea separador de segunda planta por puerta
	lineas(-2.5,1.3,1,2.8);
	//cuadro izq puerta
	lineas(-1,-15,-0.5,-14.4);
	lineas(-1,-15,-1,-11.8);
	lineas(-1,-11.8,-0.5,-11.4);
	lineas(-0.5,-14.5,-0.5,-11.4);
	//cuarto  der puerta
	lineas(-0.35,-14.2,0.2,-13.8);
	lineas(-0.35,-14.2,-0.35,-11.3);
	lineas(-0.35,-11.3,0.2,-11);
	lineas(0.2,-11,0.2,-13.8);
	//~ lineas(-1,-15,-1,-11.8);
	//~ lineas(-1,-11.8,-0.5,-11.4);
	//~ lineas(-0.5,-14.5,-0.5,-11.4);
	
	//ventanas segunda planta izquierdo
	ventanas(-10,-2.2,6,4,160,2);
	ventanas(-5,-4,6,4,160,2);
	//ventana segunda planta puerta
	ventanas(-1.5,-3.6,5,2,25,1);
	//ventana de cochera
	ventanas(-12,-15.5,3.5,2,150,1);
	//ventana cuarto
	ventanas(6,-11,6,6,25,3);
	//ventana segunda planta derecho
	ventanas(6,-1,5,5,25,3);
	
	lineas(1,-5,3,-5.5);// linea separador de cuarto segunda planta
	lineas(1,2.5,3,2);//linea separador techo
	lineas(1,2.8,3,2.3);
	lineas(3,-15,3,2);//linea cuarto
	lineas(3,-15,1,-14.3);
	lineas(3,-15,14,-10);
	lineas(14,-10,14,7);//linea derecha de cuarto
	lineas(3,-5.5,14,-0.5);//linea separador segunda planta de cuarto

	//techo
	lineas(3,2.3,8,12);
	lineas(8,12,14,7);
	lineas(3,2.6,8,12.3);
	lineas(8,12.3,14,7.3);
	lineas(8,12.3,0,15);
	lineas(1,2.8,0,15);
	lineas(-2.5,1.3,-10,13);
	lineas(-10,13,-15,6.5);
	lineas(-2.5,1.1,-10,12.8);
	lineas(-10,12.7,-15,6.2);
	lineas(-10,13,-5,17);
	//chimenea
	lineas(-5,17,-4,15);
	lineas(-4,15,-2,16.2);
	lineas(-4,15,-4,18);
	lineas(-2,16.2,-2,18.9);
	lineas(-2,18.9,-4,18);
	lineas(-4,18,-6,18.5);
	lineas(-6,18.5,-6,16.1);
	lineas(-2,18.9,-4,19.3);
	lineas(-4,19.3,-6,18.5);
	lineas(-2,18,2,20);
	lineas(2,20,5,13.3);
}

void display(void)
{
	glClearColor(1,1,1,0.0); 
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0f,0.0f,0.0f); 
    casa();
    glEnd();
    glFlush ();
}


void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(ortho), ortho, -(ortho), ortho, -(ortho), ortho); 
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (800, 600);
    glutInitWindowPosition (50, 300);
    glutCreateWindow ("Casa");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

