//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
float ortho=10;

void puntos(float x,float y)
{
	glBegin(GL_POINTS);
	glVertex2f(x,y);
	glEnd();
	}
void lineas(GLdouble x1,GLdouble y1,GLdouble x2,GLdouble y2)
{
	glBegin(GL_LINES);
	glVertex2f(x1,y1);
	glVertex2f(x2,y2);
	glEnd();

}

void parabola(float xin,float yin,float x, float x2)
{
	 float y;
    float xinicio=xin;
    float yinicio=yin;
    for (float i = x; i<=x2; i+=0.001)
	{
      y = pow(i,2.5);
      y=0.09*y;
      puntos(xinicio + i,yinicio + y);
    }
}

void circulos(float x, float y, float anguloI, float anguloF, float r)
{
  glPointSize(1.0f);
  glBegin(GL_POINTS);
  float cx=0;
  float cy=0;
  float angulo;
  for (float i=anguloI; i<anguloF; i+=0.01)
  {
	 angulo=i*M_PI/180;
    cx=r*cos(angulo)+x;
    cy=r*sin(angulo)+y;
    glVertex2f(cx,cy);
  }
   glEnd();
}

void grifo()
{
	glColor3f(1,1,1); 
	circulos(0,8,300,600,0.8);
	//perilla der
	lineas(0.8,8,3,8.7);
	lineas(0.8,8,3,7.4);
	lineas(3,8.7,3,7.4);
	//perilla izq
	lineas(-0.8,8,-3,8.7);
	lineas(-0.8,8,-3,7.4);
	lineas(-3,8.7,-3,7.4);
	//tubo
	lineas(0.4,7.3,0.4,5);
	lineas(-0.4,7.3,-0.4,5);
	//soporte
	lineas(1.4,5,-1.4,5);
	lineas(1.4,5,1.4,3.7);
	lineas(-1.4,5,-1.4,3.7);
	
	lineas(-1.7,3.7,1.7,3.7);
	lineas(-1.7,3.7,-1.7,2.4);
	lineas(1.7,3.7,1.7,2.4);

	circulos(3.7,2.4,180,270,2);
	circulos(-3.7,2.4,270,360,2);
	circulos(-3.7,-2.5,90,180,3);//
	lineas(3.7,0.4,5.5,0.4);//linea
	//superior derecho
	circulos(5.5,0.9,270,360,0.5);
	lineas(6,0.9,6.8,0.9);//
	lineas(6.8,0.9,6.8,-3);
	lineas(6,-3,6.8,-3);//
	//inferior derecho
	circulos(5.5,-3,0,90,0.5);
	lineas(1.5,-2.5,5.5,-2.5);
	circulos(1.5,-3,90,180,0.5);
	circulos(0,-3,180,360,1);//centro
	circulos(-1.5,-3,0,90,0.5);
	lineas(-1.5,-2.5,-3.3,-2.5);
	circulos(-3.3,-3,90,180,0.5);
	lineas(-3.8,-3,-3.8,-4.3);
	lineas(-6.7,-2.5,-6.7,-4.3);
	lineas(-3.8,-4.3,-6.7,-4.3);
}
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    grifo();
    glEnd();
    glFlush ();
}


void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(ortho), ortho, -(ortho), ortho, -(ortho), ortho); 
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 400);
    glutInitWindowPosition (500, 500);
    glutCreateWindow ("Grifo");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

