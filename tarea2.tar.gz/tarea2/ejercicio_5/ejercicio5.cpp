//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
float ortho=10;

void puntos(float x,float y)
{
	glBegin(GL_POINTS);
	glVertex2f(x,y);
	glEnd();
	}
void lineas(GLdouble x1,GLdouble y1,GLdouble x2,GLdouble y2)
{
	glBegin(GL_LINES);
	glVertex2f(x1,y1);
	glVertex2f(x2,y2);
	glEnd();

}

void parabola(float xin,float yin,float x, float x2)
{
	 float y;
    float xinicio=xin;
    float yinicio=yin;
    for (float i = x; i<=x2; i+=0.001)
    {
      y = pow(i,2.5);
      y=0.09*y;
      puntos(xinicio + i,yinicio + y);
    }
}

void circulos(float x, float y, float anguloI, float anguloF)
{
  glPointSize(1.0f);
  glBegin(GL_POINTS);
  GLfloat cx=0;
  GLfloat cy=0;
  GLfloat angulo;
  for (float i=anguloI; i<anguloF; i+=0.01)
  {
    cx=cos(i)+x;
    cy=sin(i)+y;
    glVertex2f(cx,cy);
  }
   glEnd();
}

void figura()
{
	glColor3f(1,1,1); 
	lineas(-2.72,4.43, 1.53,8);
    lineas(-1.22,4.37, 3.06,8.06);
    lineas(-2.72,4.43,-1.22,4.37);
    lineas(1.53,8,3.06,8.06);
    lineas(-2.72,4.43, -2.7, -5.41);
    lineas(-1.22,4.37, -1.2, -3.6);
    //pared triangular
    lineas(1.71,-0.05, 1.58, 6.78);
    lineas(-1.2, -3.6, 1.71,-0.05);
    lineas(7.16,-2.02, 1.58, 6.78);
    lineas(7.16,-2.02, 1.71,-0.05);
    lineas(8.08,-0.77, 3.06,8.06);
    //ventana dentro
    lineas(-0.62,3.46,-0.61,-0.78);
    lineas(-0.62,3.46,1,5);
    lineas(1,1,1,5);
    lineas(1,1,-0.61,-0.78);
    lineas(1,1,0.11,1.38);
    lineas(-0.62,0.6,0.11,1.38);
    lineas(0.11,4.2,0.11,1.38);
    
    lineas(3.0,-5.3, -1.2, -3.6);
    lineas(8.08,-0.77, 4.9,-4.90);
    lineas(8.08,-0.77, 8.08,-3.0);
	
	lineas(8.08,-3.0, 4.5,-7.4);
    lineas(-2.7,-5.41, 3.35, -7.5);
    
	parabola(3.0,-5.3,0,2);
	parabola(3.35,-7.5,0,1.3);
	
	circulos(3.5,-3.5,0,360);
}
	
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    figura();
    glEnd();
    glFlush ();
}


void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(ortho), ortho, -(ortho), ortho, -(ortho), ortho); 
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 400);
    glutInitWindowPosition (500, 500);
    glutCreateWindow ("Ejercicio 5");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

