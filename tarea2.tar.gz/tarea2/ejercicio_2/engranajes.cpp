//Stefany Magaly Hernandez Hernandez HH14012
 #include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
float ortho=10;

void puntos(float x,float y)
{
	glBegin(GL_POINTS);
	glVertex2f(x,y);
	glEnd();
}
void lineas(GLdouble x1,GLdouble y1,GLdouble x2,GLdouble y2)
{
	glBegin(GL_LINES);
	glVertex2f(x1,y1);
	glVertex2f(x2,y2);
	glEnd();
}

void parabola(float xin,float yin,float x, float x2)
{
	 float y;
    float xinicio=xin;
    float yinicio=yin;
    for (float i = x; i<=x2; i+=0.001) 
    {
      y = pow(i,2.5);
      y=0.09*y;
      puntos(xinicio + i,yinicio + y);
    }
}

void circulos(float x, float y, float anguloI, float anguloF, float r)
{
  glPointSize(1.0f);
  glBegin(GL_POINTS);
  float cx=0;
  float cy=0;
  float angulo;
  for (float i=anguloI; i<anguloF; i+=0.01)
  {
	 angulo=i*M_PI/180;
    cx=r*cos(angulo)+x;
    cy=r*sin(angulo)+y;
    glVertex2f(cx,cy);
  }
   glEnd();
}

void engranajes(float x,float y)
{
	glBegin(GL_POLYGON);
	int j=0;
	float h=0;
	float cx=x,cy=y;
	float angulo;
	
	for(float i=0;i<=360;i+=1)
	{
		
		if(h<=10 && j==0)
		{
			glVertex2f(cx,cy);
			angulo=i*M_PI/140;
			cx=3*cos(angulo)+x;
			cy=3*sin(angulo)+y;
			glVertex2f(cx,cy);
			if(h==10)
			{
				h=0;
				j=1;
			}
		}
		if(h<=10 && j==1)
		{
			glVertex2f(cx,cy);
			angulo=i*M_PI/140;
			cx=2*cos(angulo)+x;
			cy=2*sin(angulo)+y;
			glVertex2f(cx,cy);
			if(h==10)
			{
				h=0;
				j=0;
			}
		}
		h+=0.5;
	}
		glEnd();
		
		cx=x,cy=y;
		for(float i=0;i<=360;i+=1)
		{
			
			glBegin(GL_POLYGON);
			glColor3f(1.0f,1.0f,1.0f); //color azul
			glVertex2f(cx,cy);
			angulo=i*M_PI/140;
			cx=cos(angulo)+x;
			cy=sin(angulo)+y;
			glVertex2f(cx,cy);
		}
			glEnd();
}
void display(void)
{
	glClearColor(1.0, 1.0, 1.0,0.0); 
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.0f,0.0f,0.0f); 
    engranajes(0,0);
    glColor3f(0.0, 0.5, 0.0 ); 
    engranajes(-4,-3);
    glColor3f(0.502, 0.502, 0.502); 
    engranajes(4,-3);
    glEnd();
    glFlush ();
}


void init (void)
{
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-(ortho), ortho, -(ortho), ortho, -(ortho), ortho); 
}


int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (600, 400);
    glutInitWindowPosition (500, 500);
    glutCreateWindow ("Engranajes");
    init ();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

